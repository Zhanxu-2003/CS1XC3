/**
 * @mainpage Program to relate the students to the courses.
 *
 * Use several different functions to connect the students with the course and print out the whole information
 *
 *
 *
 * @file course.c
 * @author Zhanxu Ye (yez69@mcmaster.ca)
 * @date 2022-04-11
 * @version 0.1
 * @brief Functions with library
 * 
 * @copyright Copyright (c) 2022
 */
 



#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"


/**
 * Create course named MATH101 at first, then use function enroll_student, top_student, passing and print_course to print all information between course and students
 * @return 0 (executed successfully)
 */

int main()
{
  srand((unsigned) time(NULL));
  
  // set pointer Math101 and give Math101 a name and code 
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  /** Twenty students were created to sign up for this course */
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student; // set pointer student
  student = top_student(MATH101); // set student = the student who has the highest average in course MATH101
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing; // set integer total_passing
  Student *passing_students = passing(MATH101, &total_passing); // pointer passing_student = the number of student who pass the course MATH101
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]); /** loop all passing students and print out their information */
  
  return 0;
}