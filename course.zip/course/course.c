/**
* @file course.c
* @author Zhanxu Ye
* @date 2022-04-11
* @brief Functions with library
*/

#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 


/**
 * Enrolls student into a course
 * -> mean pointers to structs 
 * In line (28): course->students create one space
 * But in line (33), because we wanna extra space, so we use realloc to change the space from one to the number we want
 * @param course is a pointer course
 * @param student is a pointer to students being enrolled
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++; // increse course's total_students
  if (course->total_students == 1) // if course's total_students = 1
  {
    course->students = calloc(1, sizeof(Student)); // course's students create one space
  }
  else  // other situations
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); // course's students's space change from one to the value of course's total_students 
  }
  course->students[course->total_students - 1] = *student;
}

/** 
 * Print out the name, code, total students
 * @param course is a pointer course
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) /** look over all students in this course */
    print_student(&course->students[i]);
}
/** 
 * Find the student who have the highest average in this course
 * @param course is a pointer course
 * @return the pointer student who has the highest avg
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; // if course's total_students = 0, return NULL
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++) /** loop when i < the value of course's total_students and until we find the student who have the highest avg. */
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) // if student_average > max_average
    {
      max_average = student_average;
      student = &course->students[i];  // find the best student
    }   
  }

  return student; 
}

/** 
 * Find the number of people who passing this course
 * @param course is a pointer course
 * @return the pointer passing and show how many students passing this course
 */
// Function definition (how many people pass the course)
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) /** look over all students in this course */
    if (average(&course->students[i]) >= 50) count++; // if the value of course's students[i] > or = 50, increase count, check if the mark >= 50
  
  passing = calloc(count, sizeof(Student)); // passing create the number of count's space

  int j = 0;
  for (int i = 0; i < course->total_students; i++) /** loop when i < course's total_students, look over all students */
  {
    if (average(&course->students[i]) >= 50)  // if function average(course's students[i] >= 50), check if the mark >= 50
    {
      passing[j] = course->students[i];  // passing[j] replace the course's students[i]
      j++; // J increase 1 in each round loop
    }
  }

  *total_passing = count;

  return passing;
}