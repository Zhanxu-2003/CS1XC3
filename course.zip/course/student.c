/**
* @file course.c
* @author Zhanxu Ye (yez69@mcmaster.ca)
* @date 2022-04-11
* @version 0.1
* @brief Functions with library
* 
* @copyright Copyright (c) 2022
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"



/**
 * Adds grade to the corresponding student
 * -> mean pointers to structs 
 * @param student is a pointer to the corresponding student
 * @param grade is the grade assigned to the corresponding student
 * @return nothing
 * In line (15): student->grades create one space as initial
 * But in line (19), because we wanna extra space, so we use realloc to change the space from one to the number we want
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++;  // increase (pointer) student's num_grades (struct)
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); // if sudent's num_grades = 1, student's grades create one space
  else // other situations
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades); // student's grades' space change to the value of student->num_grades
  }
  student->grades[student->num_grades - 1] = grade; 
}


/**
 * Find the average of the student
 * @param student is a pointer to the student who is looking for the average 
 * @return average of students grades
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0; // if student's num_grades = 0, return 0

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; /** look over all student's grade and ready to be calulated */
  return total / ((double) student->num_grades);
}


/**
 * Print out the student's name, id, grades, averages
 * @param student is a pointer to look all students
 * @return nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) /** look over all student's grades */
    printf("%.2f ", student->grades[i]); // print each student's grades' values and keep each value's spacing at 2
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}


/**
 * Return the whole new random students' name
 * @param grades is the student's grade
 * @return brand new student's name
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = // array
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] =  // array
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 

 Student *new_student = calloc(1, sizeof(Student)); // pointer new_student create one space

  strcpy(new_student->first_name, first_names[rand() % 24]); // random first name
  strcpy(new_student->last_name, last_names[rand() % 24]); // random last name

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48); /** random id */
  new_student->id[10] = '\0';  

  for (int i = 0; i < grades; i++) /** random grades */
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}