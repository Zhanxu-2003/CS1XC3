var searchData=
[
  ['passing_0',['passing',['../course_8c.html#ab1ba9629dc52188231bb689d3a855813',1,'passing(Course *course, int *total_passing):&#160;course.c'],['../course_8h.html#ab1ba9629dc52188231bb689d3a855813',1,'passing(Course *course, int *total_passing):&#160;course.c']]],
  ['print_5fcourse_1',['print_course',['../course_8c.html#a99bf8b3f3c2d5dc7cf798ed445eaaa77',1,'print_course(Course *course):&#160;course.c'],['../course_8h.html#a99bf8b3f3c2d5dc7cf798ed445eaaa77',1,'print_course(Course *course):&#160;course.c']]],
  ['print_5fstudent_2',['print_student',['../student_8c.html#a4d964bf73eb1b291728dbf7380a9e6ab',1,'print_student(Student *student):&#160;student.c'],['../student_8h.html#a4d964bf73eb1b291728dbf7380a9e6ab',1,'print_student(Student *student):&#160;student.c']]],
  ['program_20to_20relate_20the_20students_20to_20the_20courses_2e_3',['Program to relate the students to the courses.',['../index.html',1,'']]]
];
