var searchData=
[
  ['name_0',['name',['../struct__course.html#aeaf846aa21a7d016a52f0b5b0c2f5544',1,'_course']]],
  ['num_5fgrades_1',['num_grades',['../struct__student.html#aede90734d1fafb541757aa6934618a33',1,'_student']]]
];
