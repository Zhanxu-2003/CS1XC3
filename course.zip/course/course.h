/**
* @file course.c
* @author Zhanxu Ye
* @date 2022-04-11
* @brief Functions with library
*/

#include "student.h"
#include <stdbool.h>
 

/**
* Course type store a course with name, code, student, total_student
*/

typedef struct _course 
{
  char name[100]; /** the course's name */
  char code[10]; /** the course's code */
  Student *students; /** the course's students */
  int total_students; /** the course's total_students */
} Course; /** New type: Course*/

/** Function declaration */
void enroll_student(Course *course, Student *student);  /** student who enroll */
void print_course(Course *course); /** print course */
Student *top_student(Course* course); /** student who has highest average */
Student *passing(Course* course, int *total_passing); /** students who pass the course */


