 /**
* @file course.c
* @author Zhanxu Ye
* @date 2022-04-11
* @brief Functions with library
*/


/**
* Student type store first_name, last_name, id, grades, num_grades
*/
typedef struct _student 
{ 
  char first_name[50]; /** the student's first name */
  char last_name[50]; /** the student's last name */
  char id[11]; /** the student's id */
  double *grades;  /** the student's grades */
  int num_grades;  /** the student's num_grades */
} Student; /** New type: Student */

/** Function declaration */
void add_grade(Student *student, double grade);  /** student who add grade */
double average(Student *student);   /** student's average */
void print_student(Student *student); /** print out student */
Student* generate_random_student(int grades);   /** student's grade*/
